/**
 * \file libtiepiematlab.h
 * \brief Special header for Matlab.
 */

#ifndef _LIBTIEPIEMATLAB_H_
#define _LIBTIEPIEMATLAB_H_

#define INCLUDED_BY_MATLAB

#include "libtiepie.h"

#endif
