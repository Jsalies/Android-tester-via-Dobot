== INSTALLATION ==

Refer to the install.txt file.


== API DOCUMENTATION ==

API documentation for LibTiePie can be found at http://api.tiepie.com/libtiepie .


== EXAMPLES / BINDINGS ==

For programming examples and bindings refer to http://www.tiepie.com/libtiepie .
