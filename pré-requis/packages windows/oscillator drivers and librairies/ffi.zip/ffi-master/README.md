ffi moved
=========

"ffi" has been renamed "cffi" and moved.

* new web site: https://bitbucket.org/cffi/cffi

* mailing list: https://groups.google.com/forum/#!forum/python-cffi
